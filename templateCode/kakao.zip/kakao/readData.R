setwd()
chatroom = fromJSON("./data/chatroom.json")
user = fromJSON("./data/user.json")

str(chatroom); head(chatroom)
str(user); head(user)